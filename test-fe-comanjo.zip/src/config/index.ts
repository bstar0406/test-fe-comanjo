const config={
    // baseURL:"http://localhost:5100/api/",
    baseURL:"https://hs-iota.herokuapp.com/api/",
}

export default config;